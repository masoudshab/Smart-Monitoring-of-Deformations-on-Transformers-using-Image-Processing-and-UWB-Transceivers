def cap_text(text):
    return text.title()  # replace .capitalize() with .title()